let express = require("express")
let mongoose = require("mongoose")
const { required } = require("nodemon/lib/config")
const { stringify } = require("nodemon/lib/utils")

let app = express()


// connect
let connect = ()=>{
   return mongoose.connect("mongodb+srv://dhaval:dhaval_123@cluster0.ljuvz.mongodb.net/web15-atlas?retryWrites=true&w=majority")
}


let userSchema = new mongoose.Schema(
    {
        firstName:{type:String , required:true},
        lastName :{type:String},
        email : {type:String , required:true},
        password : {type:String  ,required:true},
    },
    {
        timestamps:true,
        versionKey:false
    }
);


let User = mongoose.model("user",userSchema);



let postSchema = new mongoose.Schema({
    title:{type:String,required:true},
    body:{type : String , required:true},
    userId:{
        type:mongoose.Schema.Types.ObjectId,
        ref : "user",
        required:true
    }
},{
    timestamps:true,
    versionKey:false
});

let Post = mongoose.model("post",postSchema)


let commentSchema = new mongoose.Schema(
    {
       body:{type:String , required:true},
       userId:{
           type:mongoose.Schema.Types.ObjectId,
           ref :"user",
           required:true
       },
       postId:{
           type:mongoose.Schema.Types.ObjectId,
           ref:"post",
           required:true,
       },
       
    },
    {
        timestamps:true,
        versionKey:false,
    }
    
) 

let Comment = mongoose.model("comment",commentSchema)

//CRUD 
// get , post , patch , delete // find by id

app.get("/user",async(req,res)=>{
    try{
        let user = await User.find({}).lean().exec()
        return res.status(200).send({user:user})
    }
    catch(err){
        res.status(500).send({ message: err.message })
    }
})

app.post("/user",async(req,res)=>{
    try{
        let user = await User.create(req.body)
        return res.status(200).send({user:user})
    }
    catch(err){
        res.status(500).send({ message: err.message })
    }
})

app.patch("/user/:id",async(req,res)=>{
    try{
        let user = await User.findByIdAndUpdate(req.params.id,req.body,{new:true}).lean().exec()
        return res.status(200).send({user:user})
    }
    catch(err){
        res.status(500).send({ message: err.message })
    }
})

app.delete("/user/:id",async(req,res)=>{
    try{
      let user = await User.findByIdAndDelete(req.params.id).lean().exec()
      return res.status(200).send({user:user})
    }
    catch(err){
        res.status(500).send({ message: err.message })
    }
})

app.get("/user/:id",async(req,res)=>{
    try{
    let user = await User.findById(req.params.id).lean().exec()
    return res.status(200).send({user:user})
    }
    catch(err){
        res.status(500).send({ message: err.message })
    }
})

//post

app.get("/post",async(req,res)=>{
    try{
     let post = await Post.find().lean().populate({path:"userId",select:{"firstName":1,_id:0}}).exec()
     return res.status(200).send({post:post})
    }
    catch(err){
        res.status(500).send({ message: err.message })
    }
})

app.post("/post",async(req,res)=>{
    try{
        let post = await Post.create(req.body)
        return res.status(200).send({post:post})
    }
    catch(err){
        res.status(500).send({ message: err.message })
    }
})

app.patch("post/:id",async(req,res)=>{
    try{
        let post  = await Post.findByIdAndUpdate(req.params.id,req.body,{new:true}).lean().exec()
        return res.status(200).send({post:post})
    }
    catch(err){
        res.status(500).send({ message: err.message })
    }
})

app.delete("post/:id",async(req,res)=>{
    try{
      let post = await Post.findByIdAndDelete(req.params.id).lean().exec()
      return res.status(200).send({post:post})
    }
    catch(err){
        res.status(500).send({ message: err.message })
    }
})

app.get("post/:id",async(req,res)=>{
    try{
    let post = await Post.findById(req.params.id).lean().exec()
    return res.status(200).send({post:post})
    }
    catch(err){
        res.status(500).send({ message: err.message })
    }
})

// comment
app.get("/comment",async(req,res)=>{
    try{
     let comment = await Comment.find().lean().exec()
     return res.status(200).send({comment:comment})
    }
    catch(err){
        res.status(500).send({ message: err.message })
    }
})

app.post("/comment",async(req,res)=>{
    try{
        let post = await Post.create(req.body)
        return res.status(200).send({post:post})
    }
    catch(err){
        res.status(500).send({ message: err.message })
    }
})

app.patch("comment/:id",async(req,res)=>{
    try{
        let comment  = await Comment.findByIdAndUpdate(req.params.id,req.body,{new:true}).lean().exec()
        return res.status(200).send({comment:comment})
    }
    catch(err){
        res.status(500).send({ message: err.message })
    }
})

app.delete("comment/:id",async(req,res)=>{
    try{
      let comment = await Comment.findByIdAndDelete(req.params.id).lean().exec()
      return res.status(200).send({comment:comment})
    }
    catch(err){
        res.status(500).send({ message: err.message })
    }
})

app.get("post/:id",async(req,res)=>{
    try{
    let comment = await Comment.findById(req.params.id).lean().exec()
    return res.status(200).send({comment:comment})
    }
    catch(err){
        res.status(500).send({ message: err.message })
    }
})




app.listen("6000",async()=>{
   try{ 
      await connect()
   }
catch(err){
   console.log(err)
}
console.log("This is portal 6000")
})